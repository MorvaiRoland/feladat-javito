﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace futar
{
    class Futar
    {
        public int nap;
        public int fuvarszam;
        public int megtettkm;

        public Futar(string sor)
        {
            string[] resz = sor.Split(' ');
            nap = int.Parse(resz[0]);
            fuvarszam = int.Parse(resz[1]);
            megtettkm = int.Parse(resz[2]);

        }
        public int osszegek 
        {
            get
            {
                int ar=0;
                if (megtettkm >= 1 && megtettkm <= 2)
                {
                    ar =500;


                }

                else if (megtettkm >= 3 && megtettkm <= 5)
                {
                    ar=700;


                }

                else if (megtettkm >= 6 && megtettkm <= 10)
                {
                    ar=900;


                }

                else if (megtettkm >= 11 && megtettkm <= 20)
                {
                    ar=1400;


                }
                else if (megtettkm >= 21 && megtettkm <= 30)
                {
                    ar=2000;


                }
                return ar;
            }


        }



    }

    class Feladat
    {
        List<Futar> adatok;
        public Feladat(string nev)
        {

            adatok = new List<Futar>();
            foreach (var item in File.ReadAllLines(nev))
            {

                adatok.Add(new Futar(item));

            }
        }

        public void Feladat2()
        {
            
            Console.WriteLine("2. feladat:");

            var f1 = adatok.Where(x => x.nap == 1 && x.fuvarszam == 1);
            foreach (var item in f1)
            {
                Console.WriteLine("Hét legelső útján megtett km: {0}",item.megtettkm);
            }


        }

        public void Feladat3()
        {
            Console.WriteLine();
            Console.WriteLine("3. feladat:");
            var f2 = adatok.Where(x => x.nap == 7);

            foreach (var item in f2)
            {
                if (item.fuvarszam == f2.Max(x=>x.fuvarszam))
                {
                    Console.WriteLine("Hét utolsó útján megtett km: {0}", item.megtettkm);
                }
            }

        }

        public void Feladat4()
        {
            Console.WriteLine();
            Console.WriteLine("4. feladat:");
           
            List<int> napok = new List<int>() { 1,2,3,4,5,6,7};
            foreach (int item in adatok.Select(x => x.nap))
            {
                
                if (napok.Contains(item))
                {
                    napok.Remove(item);
                }
            }
            napok.ForEach(x => Console.Write($"{x} "));
            System.Console.WriteLine("napokon nem dolgozott a futár.");

        }

        public void Feladat5()
        {
            Console.WriteLine();
            Console.WriteLine("5. feladat:");

             var f4=adatok.Max(x=>x.fuvarszam);
            Console.WriteLine("Legtöbb fuvar száma a héten: {0}",f4);

            

           
            
         

        }


        public void Feladat6()
        {
            Console.WriteLine();
            Console.WriteLine("6. feladat:");
            int elso=0;
            int masodik=0;
            int harmadik=0;
            int negyedik=0;
            int otodik=0;
            int hatodik=0;
            int hetedik=0;
            foreach (var item in adatok)
            {
                if(item.nap==1)
                {
                    elso += item.megtettkm;


                }
                else if (item.nap == 2)
                {
                    masodik += item.megtettkm;


                }
                else if (item.nap == 3)
                {
                    harmadik += item.megtettkm;


                }
                else if (item.nap == 4)
                {
                    negyedik += item.megtettkm;


                }
                else if (item.nap == 5)
                {
                    otodik += item.megtettkm;


                }
                else if (item.nap == 6)
                {
                    hatodik += item.megtettkm;


                }
                else if (item.nap == 7)
                {
                    hetedik += item.megtettkm;


                }
            }
            Console.WriteLine($"1. nap: {elso}km");
            Console.WriteLine($"2. nap: {masodik}km");
            Console.WriteLine($"3. nap: {harmadik}km");
            Console.WriteLine($"4. nap: {negyedik}km");
            Console.WriteLine($"5. nap: {otodik}km");
            Console.WriteLine($"6. nap: {hatodik}km");
            Console.WriteLine($"7. nap: {hetedik}km");

        }
        public void Feladat7()
        {
            Console.WriteLine();
            Console.WriteLine("7. feladat:");

            Console.Write("Adj meg egy távolságot: ");

            int tavolsag=int.Parse(Console.ReadLine());

            if(tavolsag>=1&&tavolsag<=2)
            {
                Console.WriteLine("Díjazás értéke: 500Ft");


            }

            else if(tavolsag >= 3 && tavolsag <= 5)
            {
                Console.WriteLine("Díjazás értéke: 700Ft");


            }

            else if (tavolsag >= 6 && tavolsag <= 10)
            {
                Console.WriteLine("Díjazás értéke: 900Ft");


            }

            else if (tavolsag >= 11 && tavolsag <= 20)
            {
                Console.WriteLine("Díjazás értéke: 1400Ft");


            }
            else if (tavolsag >= 21 && tavolsag <= 30)
            {
                Console.WriteLine("Díjazás értéke: 2000Ft");


            }


        }
        public void Feladat8()
        {
            Console.WriteLine();
            Console.WriteLine("8. feladat: Kiíratás megtörtént");
            StreamWriter fajl = new StreamWriter("dijazas.txt");

            var f8 = adatok.OrderBy(x => x.nap).ThenBy(x=>x.fuvarszam);
            
            foreach (var item in f8)
            {
                fajl.WriteLine($"{item.nap}. nap {item.fuvarszam}. út: {item.osszegek} Ft ");
            }
            fajl.Close();




        }

        public void Feladat9()
        {

            Console.WriteLine();
            Console.WriteLine("9. feladat:");
           
            int osszeg = 0;

            foreach (var item in adatok)
            {
                int tav = item.megtettkm;
                if (tav >= 1 && tav <= 2)
                {
                    osszeg = osszeg + 500;


                }

                else if (tav >= 3 && tav <= 5)
                {
                    osszeg = osszeg + 700;


                }

                else if (tav>= 6 && tav<= 10)
                {
                    osszeg = osszeg + 900;


                }

                else if (tav>= 11 && tav <= 20)
                {
                    osszeg = osszeg + 1400;


                }
                else if (tav>= 21 && tav<= 30)
                {
                    osszeg = osszeg + 2000;


                }

            }

            Console.WriteLine("Ennyit keresett a futár egy hét alatt: {0} Ft",osszeg);

        }



    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Feladat f = new Feladat("tavok.txt");
            f.Feladat2();
            f.Feladat3();
            f.Feladat4();
            f.Feladat5();
            f.Feladat6();
            f.Feladat7();
            f.Feladat8();
            f.Feladat9();
            Console.ReadKey();
        }
    }
}
